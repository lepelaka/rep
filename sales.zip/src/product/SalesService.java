package product;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
public class SalesService {
	List<Sales> sales = new ArrayList<Sales>();
	{
		/*
		 * 코드 작성 부분 
		 */
	}
	
	
	// 개요 조회
	public void summary() {
		int result = 0;
		Set<Integer> weeks = new TreeSet<Integer>();
		
		
		System.out.println("====================================================== summary ======================================================");
		for(Sales p : sales) {
			/*
			 * 코드 작성 부분 
			 */
		}
		
		System.out.println("총 매출은 " + Utils.toNumberFormat(result) + "원입니다");
		
		for(Integer w : weeks) {
			int sum = 0;
			for(Sales s : sales) {
				/*
				 * 코드 작성 부분 
				 */
			}
			System.out.println(w + "주차의 매출액 :: " + Utils.toNumberFormat(sum) + "원");
		}
	}
	
	

	// 목록 조회
	public void list() {
		System.out.println("====================================================== list ======================================================");
		System.out.print(Utils.format("매출번호", 15));
		System.out.print(Utils.format("연도", 15));
		System.out.print(Utils.format("주", 10));
		System.out.print(Utils.format("요일", 10));
		System.out.println(Utils.format("금액", 30));
		
		System.out.println("===========================================================================================================");
		for(Sales p : sales) { 
			/*
			 * 코드 작성 부분 
			 */
		}
	}

	// 상품 추가
	public void add() {
		System.out.println("====================================================== add ======================================================");
		/*
		 * 코드 작성 부분 
		 */
	}
}
