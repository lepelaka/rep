package product;
public class SalesEx {
	public static void main(String[] args) {
		SalesService productService = new SalesService(); 
		
		productService.list();
		productService.summary();
		productService.add();
		productService.list();
		productService.summary();
	}
}
