package product;
public class Sales {
	
}
